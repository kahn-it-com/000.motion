import React from 'react';

export const BackgroundElements: React.FC = () => {
  return (
    <div id="metaverse-background-layer" className="absolute inset-0 pointer-events-none overflow-hidden select-none z-0">
      {/* Base Dark Background */}
      <div className="absolute inset-0 bg-[#0c0c0e]" />

      {/* Red Angular Slice (Right/Top area matching screenshot) */}
      <div
        className="absolute top-0 right-0 w-[62%] h-full bg-[#d61c28]"
        style={{
          clipPath: 'polygon(28% 0%, 100% 0%, 100% 100%, 0% 100%)',
        }}
      />

      {/* Secondary Dynamic Deep Red Layer for depth */}
      <div
        className="absolute top-0 right-0 w-[55%] h-full bg-[#b8121d] opacity-40 mix-blend-multiply"
        style={{
          clipPath: 'polygon(45% 0%, 100% 0%, 100% 100%, 15% 100%)',
        }}
      />

      {/* Comic Halftone Overlay on Red Side */}
      <div
        className="absolute top-0 right-0 w-[62%] h-full opacity-20 pointer-events-none"
        style={{
          clipPath: 'polygon(28% 0%, 100% 0%, 100% 100%, 0% 100%)',
          backgroundImage: 'radial-gradient(#000000 15%, transparent 16%)',
          backgroundSize: '12px 12px',
        }}
      />

      {/* Subtle Starburst Silhouette in the Background (left side like the image) */}
      <svg
        className="absolute -top-16 -left-20 w-[600px] h-[600px] opacity-10 text-white fill-current"
        viewBox="0 0 100 100"
      >
        <polygon points="50,0 63,38 100,50 63,62 50,100 37,62 0,50 37,38" />
      </svg>

      {/* Starburst on the Red Side (right side) */}
      <svg
        className="absolute -bottom-24 right-48 w-[750px] h-[750px] opacity-15 text-black fill-current"
        viewBox="0 0 100 100"
      >
        <polygon points="50,5 64,36 98,50 64,64 50,95 36,64 2,50 36,36" />
      </svg>

      {/* Speed lines / slashes subtle overlay */}
      <div className="absolute inset-0 bg-comic-lines opacity-10" />

      {/* Vignette border */}
      <div className="absolute inset-0 shadow-[inset_0_0_120px_rgba(0,0,0,0.85)]" />
    </div>
  );
};
