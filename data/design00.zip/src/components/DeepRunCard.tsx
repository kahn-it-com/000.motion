import React from 'react';
import { Compass, Sparkles } from 'lucide-react';
import { Protocol } from '../types';
import { sound } from '../utils/audio';

interface DeepRunCardProps {
  protocol: Protocol;
  onSelect: (protocol: Protocol) => void;
}

export const DeepRunCard: React.FC<DeepRunCardProps> = ({ protocol, onSelect }) => {
  const handleClick = () => {
    sound.playSlash();
    onSelect(protocol);
  };

  return (
    <div
      id="card-deep-run-container"
      className="relative group cursor-pointer transition-transform duration-200 hover:scale-[1.02] focus:outline-none"
      onClick={handleClick}
    >
      {/* Skewed Offset White Border Backplate (Matching Screenshot) */}
      <div
        className="absolute -inset-2 bg-white -rotate-1 translate-x-2 translate-y-1 shadow-[12px_14px_0px_rgba(0,0,0,0.7)] transition-transform duration-200 group-hover:translate-x-3 group-hover:translate-y-2"
        style={{
          clipPath: 'polygon(0% 0%, 100% 0%, 98% 100%, 0% 100%)',
        }}
      />

      {/* Main Red Halftone Pattern Body */}
      <div
        id="card-deep-run"
        className="relative w-[620px] h-[260px] bg-halftone-red text-white p-7 flex flex-col justify-between overflow-hidden shadow-xl"
        style={{
          clipPath: 'polygon(0% 0%, 100% 0%, 99% 100%, 0% 100%)',
        }}
      >
        {/* Top Row: DEEP RUN Badge & Stamp Icon */}
        <div className="flex items-start justify-between z-10">
          {/* Black Slanted DEEP RUN Badge */}
          <div
            className="bg-black text-white px-6 py-1.5 font-anton italic text-xl tracking-wider inline-block -skew-x-12 shadow-md border-l-4 border-white"
            style={{ clipPath: 'polygon(0 0, 100% 0, 90% 100%, 0% 100%)' }}
          >
            <span className="inline-block transform skew-x-12">DEEP RUN</span>
          </div>

          {/* Graphic Stamp Icon in Top Right (Square frame) */}
          <div className="w-8 h-8 border-2 border-black/80 bg-white/90 text-black flex items-center justify-center font-bold text-xs shadow-sm">
            <Compass size={18} className="text-black stroke-[2.5]" />
          </div>
        </div>

        {/* Title: MEMENTOS RUN with 3D Black Cutout Shadow */}
        <div className="my-auto py-1 z-10">
          <div className="relative inline-block">
            {/* Black Extrusion Drop Shadow */}
            <h3
              className="text-5xl font-anton italic tracking-tight uppercase text-black absolute -top-1 -left-1 select-none"
              style={{
                fontFamily: "'Anton', sans-serif",
              }}
            >
              MEMENTOS RUN
            </h3>
            {/* Main Black Text with High Contrast White Outline / Cutout */}
            <h3
              className="text-5xl font-anton italic tracking-tight uppercase text-black relative z-10"
              style={{
                fontFamily: "'Anton', sans-serif",
                textShadow: '2px 2px 0px rgba(255,255,255,0.8), -1px -1px 0px rgba(255,255,255,0.8)',
              }}
            >
              MEMENTOS RUN
            </h3>
          </div>
        </div>

        {/* Dotted Line Separator */}
        <div className="w-full border-t border-dashed border-black/40 my-1 z-10" />

        {/* Bottom Info Row (DUNGEON MASTER & STATUS) */}
        <div className="flex items-center justify-between z-10">
          {/* Dungeon Master */}
          <div>
            <div className="text-[10px] font-mono tracking-widest text-black/90 uppercase font-extrabold">
              DUNGEON MASTER
            </div>
            <div
              className="text-2xl font-anton italic tracking-wider text-white uppercase"
              style={{
                fontFamily: "'Anton', sans-serif",
                textShadow: '2px 2px 0px #000',
              }}
            >
              {protocol.dungeonMaster}
            </div>
          </div>

          {/* Status: IN PROGRESS */}
          <div className="text-right">
            <div className="text-[10px] font-mono tracking-widest text-black/90 uppercase font-extrabold">
              STATUS
            </div>
            <div
              className="text-2xl font-anton italic tracking-wider text-black uppercase"
              style={{ fontFamily: "'Anton', sans-serif" }}
            >
              {protocol.status}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
